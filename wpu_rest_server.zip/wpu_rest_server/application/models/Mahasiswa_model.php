<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa_model extends CI_Model
{
    public function deleteMahasiswa($id)
{
    $this->db->where('id', $id);
    $this->db->delete('mahasiswa');
    return $this->db->affected_rows(); // return 1 jika berhasil, 0 jika gagal
}

}

